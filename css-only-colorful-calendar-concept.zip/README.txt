A Pen created at CodePen.io. You can find this one at https://codepen.io/davidkpiano/pen/xwyVXO.

 Based on a [Dribbble](https://dribbble.com/shots/2335073-Calendar-App-Animation) by [Kirill](https://dribbble.com/Sunnynsm) and [Ludmila Shevchenko](https://dribbble.com/LudmilaShevchenko).

Made for #CodeVember.